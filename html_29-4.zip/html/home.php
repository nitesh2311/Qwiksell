<?php
	include("config.php");
	include("session.php");

	
?>