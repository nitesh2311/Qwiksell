<!DOCTYPE html>
<html style="height: 100%;">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<head>
	<title>Welcome@QwikSell</title>
</head>

<body>
	<div class="container-fluid">
		<div class="row content" style=" background-color:#001933;">
			<br>
			<div class="col-md-1" >
				<img src="profile.png" alt="profile pic">
			</div>
			<div class="col-md-9"></div>
			<div class="col-md-1" >
				<div class="dropdown">
					<button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Batista
						<span class="caret"></span>
					</button>
					<ul class="dropdown-menu pull-right">
					  <li><a href="#">My Profile</a></li>
					  <li><a href="#">My Dashboard</a></li>
					  <li><a href="#">Logout</a></li>
					</ul>
				</div><br>
			</div>
			<div class="col-md-1" >
				<img src="profile.png" alt="profile pic"><br>
			</div>
		</div>
		<div class="row content" style=" background-color:#2e353d;">
			<div class="col-md-2" style=" background-color:#2e353d;">
				<br><br>
				<form>
					<input type="text" name="search" placeholder="Search..">
				</form>
				<br><br>
				<ul class="nav nav-pills nav-stacked">
					<li class="active"><a href="#">Home</a></li>
					<li class="dropdown">
						<a class="dropdown-toggle" data-toggle="dropdown" href="#">Electronics
							<span class="caret"></span>
						</a>
						<ul class="dropdown-menu">
							<li><a href="#">Cooler</a></li>
							<li><a href="#">Laptop</a></li>
							<li><a href="#">Mobile</a></li>
							<li><a href="#">Air Conditioner</a></li>							
							<li><a href="#">Others</a></li>
						</ul>
					</li>
					<li class="dropdown">
						<a class="dropdown-toggle" data-toggle="dropdown" href="#">Books
							<span class="caret"></span>
						</a>
						<ul class="dropdown-menu">
							<li><a href="#">Novel</a></li>
							<li><a href="#">Textbook</a></li>							
							<li><a href="#">Others</a></li>
						</ul>
					</li>
					<li class="dropdown">
						<a class="dropdown-toggle" data-toggle="dropdown" href="#">Vehicles
							<span class="caret"></span>
						</a>
						<ul class="dropdown-menu">
							<li><a href="#">Car</a></li>
							<li><a href="#">Bicycle</a></li>
							<li><a href="#">Bike</a></li>							
							<li><a href="#">Others</a></li>
						</ul>
					</li>
					<li><a href="#">Others</a></li>
				</ul>
			</div>
			<div class="col-md-10" style=" background-color:#009999;">	
				<div class="row content">
					<ul class="nav nav-pills nav-justified" style="background-color:#2e353d;">
					    <li style="background-color:#202020;"><a href="#">My Advertisements</a></li>
					    <li style="background-color:#2e353d;"><a href="#">My requirements</a></li>
					    <li style="background-color:#202020;"><a href="#">My interests</a></li>
					    <li style="background-color:#2e353d;"><a href="#">My transactions</a></li>
					</ul>
				</div>
				<hr>
				<div class="row content">
					<div class="col-md-4">	
						<div class="thumbnail">
							<img src="fb.png" alt="image">
						</div>
					</div>
					<div class="col-md-6">
						<div class="caption">
							<h3>Product Label</h3>
							<p>Description...</p>
							<p>Price: Rs. 444.00/-</p>
						</div>
					</div>
					<div class="col-md-2">
						<p>
							<a href="#" class="btn btn-primary" role="button">View Details</a>
						</p>
					</div>
				</div>
				<hr>
				<div class="row content">
					<div class="col-md-4">	
						Category: {category name}<br>
						Sub-category: {sub category name}
					</div>
					<div class="col-md-6">
						<div class="caption">
							<h3>Product Name</h3>
							<p>Description...</p>
							<p>Expected Price: {Rs. 444.00/-}</p>
						</div>
					</div>
					<div class="col-md-2">
						
					</div>
				</div>
				<hr>
				<div class="row content">
					<div class="col-md-4">	
						<div class="thumbnail">
							<img src="fb.png" alt="image">
						</div>
					</div>
					<div class="col-md-6">
						<div class="caption">
							<h3>Product Label</h3>
							<p>Description...</p>
							<p>Price: Rs. 444.00/-</p>
						</div>
					</div>
					<div class="col-md-2">
						<p>
							<a href="#" class="btn btn-primary" role="button">View</a>
							<a href="#" class="btn btn-default" role="button">Buy</a>
						</p>
					</div>
				</div>
				<hr>
				<div class="row content">
					<div class="col-md-12">	
						<table class="table table-bordered table-hover">
						    <thead  style="background-color:#001933;">
						      	<tr>
							        <th>Product</th>
							        <th>Product Id</th>
							        <th>Type</th>
							        <th>To/From</th>
							        <th>Status</th>
							        <th>Transaction Date</th>
							        <th>Price</th>
						      	</tr>
						    </thead>
						    <tbody>
						      	<tr>
							        <td>{herocycle}</td>
							        <td>{cyc45}</td>
							        <td>{bought}</td>
							        <td>{cs1130243}</td>
							        <td>{completed}</td>
							        <td>{1/4/2017}</td>
							        <td>{Rs.1000/-}</td>
						      	</tr>
						      	<tr>
							        <td>{herocycle}</td>
							        <td>{cyc45}</td>
							        <td>{bought}</td>
							        <td>{cs1130243}</td>
							        <td>{completed}</td>
							        <td>{1/4/2017}</td>
							        <td>{Rs.1000/-}</td>
						      	</tr>
						      	<tr>
							        <td>{herocycle}</td>
							        <td>{cyc45}</td>
							        <td>{bought}</td>
							        <td>{cs1130243}</td>
							        <td>{completed}</td>
							        <td>{1/4/2017}</td>
							        <td>{Rs.1000/-}</td>
						      	</tr>
						    </tbody>
						</table>
					</div>
				</div>
				<hr>
			</div>
		</div>
	</div>
	<div class="container-fluid">
		<div class="row content" style=" background-color:#001933;">
			<div class="col-md-2"></div>
			<div class="col-md-6">
				<br><p>
				&copy; 2017, QwikSell</p><br>
			</div>
			<div class="col-md-4">
				<br>
				<img src="fb.png" alt="fb" style="width: 40px">
				<a href="#">QwikSell.com</a>|
				<a href="#">About Us</a>|
				<a href="#">Contact Us</a>
				<br>
			</div>
		</div>
	</div>

</body>
</html>