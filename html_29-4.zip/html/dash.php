<?php
    include("config.php");
    include("session.php");
    $myusername=$_SESSION['login_user'];
	
	if (isset($_POST['submitforsearch'])){
		header("location: welcome.php?".$_POST['cgory']."=true&search=".$_POST['search']."");
	}
	if (isset($_GET['product_id'])){
		$p=$_GET['product_id'];

		$res=mysqli_query($db,"delete from Product where Product_ID='$p'");
		$res=mysqli_query($db,"delete from buy_request where Product_ID='$p'");
		//echo '<h3>deleted</h3';
	}
	if (isset($_POST['sold'])){
		mysqli_query($db,"update user set new_notif=1 where User_ID='".$_POST['requester']."';");
		mysqli_query($db,"update buy_request set bought=1 where Requester_ID='".$_POST['requester']."' and Product_ID='".$_POST['sold']."';");
		mysqli_query($db,"insert into Product_invoice values('".$_POST['sold']."','$myusername','".$_POST['requester']."',NOW(),0)");
		//echo '<h3>',$_POST['requester'],$_POST['sold'],'</h3>';

	}
	
	$interests=mysqli_query($db,"select * from buy_request where Requester_ID='$myusername';");
	
    $user=mysqli_fetch_array(mysqli_query($db, "select * from user where User_ID='$myusername';"));
	$eid_profile=mysqli_fetch_array(mysqli_query($db, "select * from eid_profilepic where User_ID='$myusername';"));
	
	$products=mysqli_query($db, "select Product_ID,Product_Name,Category,Decription,Expected_Price,Sold from Product where Seller_ID='$myusername';");
	$Img = mysqli_query($db, "select Product_ID,Image1,Image2,Image3,Image4 from Product where Seller_ID='$myusername';");
?>



<html style="height: 100%;">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<head>
	<title>Welcome@QwikSell</title>
</head>

<body>
	<div class="container-fluid">
		<div class="row content" style=" background-color:#001933;">
			
			
			<div class="col-md-1" >
				<br>
				<a href="ad.php" class="btn btn-primary" role="button">Post Ad</a>
			</div>
			<div class="col-md-1"></div>
			<form method="post">
				<div class="col-md-3">
					<br>
					<select class="form-control" name="cgory" id="cgory">
						<option>Select Category for Search...</option>
						<option>Others</option>
						<option>Electronics-Cooler</option>
						<option>Electronics-Air Conditioner</option>
						<option>Electronics-Laptop</option>
						<option>Electronics-Mobile</option>
						<option>Electronics-Others</option>
						<option>Vehicles-Car</option>
						<option>Vehicles-Bike</option>
						<option>Vehicles-Bicycle</option>
						<option>Vehicles-Others</option>
						<option>Books-Novel</option>
						<option>Books-Textbook</option>
						<option>Books-Others</option>
					</select>
				</div>	
				<div class="col-md-2">
					<br>

					<input type="text" name="search" id="search" placeholder="Search..">
				</div>
				<div class="col-md-1">
					<br>	
					<div class="text-center">
						<input class="btn btn-primary" type="submit" name="submitforsearch" value="Search" align="left" style="background-color:#001933;">
					</div>
				</div>	
			
			<div class="col-md-1"></div>
			<div class="col-md-1" >
				<div class="dropdown">
					<br>
					<?php 
						
						if ($user['new_notif']!=0){
							echo   '<a href="notification.php" class="btn btn-primary" role="button" style=" background-color:#880000;"  name="notification"  id="notification">Notif</a>';
						}
						else {
							echo   '<a href="notification.php" class="btn btn-primary" role="button" >Notif</a>';
						}
						
					?> 
					
				</div>
			</div>
			<div class="col-md-1" >
				<div class="dropdown">
					<br>
					<button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown"><?php echo $user['Username'] ?>
						<span class="caret"></span>
					</button> 
					<ul class="dropdown-menu pull-right">
					  <li><a href="profile.php">My Profile</a></li>
					  <li><a href="dash.php">My Dashboard</a></li>
					  <li><a href="logout.php">Logout</a></li>
					</ul>
				</div>
			</div>
			<div class="col-md-1" >
				
				<?php
				if (is_null($eid_profile['Profilepic'])){
					echo '<img src="profile.png" alt="profile pic">';
				}
				else{
					/*$query = "select Profilepic from eid_profilepic where User_ID='$myusername';";
					$result = mysqli_query($db, $query);
					while ($row = mysqli_fetch_array($result))
					{*/	echo'
						<tr>
							<td>
								<img src="data:image/jpeg;base64,'.base64_encode($eid_profile['Profilepic']).'"/>
							</td>
						</tr>';
					//}
				}	
				?>
			</div>
			</form>
		</div>
		<div class="row content" style=" background-color:#2e353d;">
			<div class="col-md-2" style=" background-color:#2e353d;">
				<br><br>
				
				
				<!-- <form method="post"> -->
				<ul class="nav nav-pills nav-stacked">
					
					<li class="active"><a href="welcome.php" >Home</a></li>
					<li class="dropdown">
						<a class="dropdown-toggle" data-toggle="dropdown"  href="#">Electronics
							<span class="caret"></span>
						</a>
						<ul class="dropdown-menu">
							<li><a href="?cooler=true" >Cooler</a></li>
							<li><a href="?laptop=true">Laptop</a></li>
							<li><a href="?mobile=true">Mobile</a></li>
							<li><a href="?ac=true">Air Conditioner</a></li>							
							<li><a href="?elec-othrs=true">Others</a></li>
						</ul>
					</li>
					<li class="dropdown">
						<a class="dropdown-toggle" data-toggle="dropdown" name="books" href="#">Books
							<span class="caret"></span>
						</a>
						<ul class="dropdown-menu">
							<li><a href="?novel=true">Novel</a></li>
							<li><a href="?txtbook=true">Textbook</a></li>							
							<li><a href="?book-othrs=true">Others</a></li>
						</ul>
					</li>
					<li class="dropdown">
						<a class="dropdown-toggle" data-toggle="dropdown" href="#">Vehicles
							<span class="caret"></span>
						</a>
						<ul class="dropdown-menu">
							<li><a href="?car=true">Car</a></li>
							<li><a href="?bicycle=true">Bicycle</a></li>
							<li><a href="?bike=true">Bike</a></li>							
							<li><a href="?vehicles-othrs=true">Others</a></li>
						</ul>
					</li>
					
					<li><a href="?others=true" >Others</a></li>
					
				</ul>
				<!-- </form> -->
			</div>
			<div class="col-md-10" style=" background-color:#009999;">	
				<div class="row content">
					<ul class="nav nav-pills nav-justified" style="background-color:#2e353d;">
					    <li style="background-color:#202020;"><a href="?ad=true">My Advertisements</a></li>
					    <li style="background-color:#2e353d;"><a href="?interest=true">My interests</a></li>
					    <li style="background-color:#202020;"><a href="?transaction=true">My transactions</a></li>
					</ul>
				</div>
				<hr>
				<!-- <div class="row content"> -->
					
					<?php 
					//if (isset($ad))	{
						$check=0;
						if (mysqli_num_rows($products)){
							while($row=mysqli_fetch_array($products)){
								
								$img=mysqli_fetch_array($Img);
								if ($row['Sold']==1){
									continue;
								}
								$check=1;
								echo '	
								
									<div class="row content">
										<div class="col-md-4">	
											
											<tr>
												<td>
													<img src="data:image/jpeg;base64,'.base64_encode($img['Image1']).'"/>
												</td>
											</tr>
										</div>
									
										<div class="col-md-6">
											<div class="caption">

												<h3>',$row['Product_Name'],'</h3>
												<p>Category : ',$row['Category'],'</p>
												<p>Description : ',$row['Decription'],'</p>
												<p>Price : &#x20B9 ' ,$row['Expected_Price'],'/-</p>
							
											</div>
										</div>
										<form method="post">
										<div class="col-md-2">
											<p>
												<a href="?product_id=',$row['Product_ID'],'" class="btn btn-primary" role="button" style="background-color:#001933;">Delete</a>
											</p>
										</div>
										</form>
									</div><br>';
								echo '<div class="row content">
										<div class="col-md-4">	
										<h3>Requesters:</h3>';
								$ress=mysqli_query($db,"select Requester_ID from buy_request where Product_ID='".$row['Product_ID']."'");
								if (mysqli_num_rows($ress)){	
									while ($row1=mysqli_fetch_array($ress)) {
									//echo '<h3>here</h3>';		
										$r=mysqli_query($db,"select * from user where User_ID='".$row1['Requester_ID']."'");
										$e=mysqli_query($db,"select Email from eid_profilepic where User_ID='".$row1['Requester_ID']."'");
										if (mysqli_num_rows($r)){
											$customer=mysqli_fetch_array($r);
											echo "<h4>Requester Name: ",$customer['Username']," </h4>";
											echo "<h4>Requester User Id: ",$customer['User_ID']," </h4>";
											echo "<h4>Requester Contact Number: ",$customer['Contact_no']," </h4>";
											if ($e!=NULL){
												$email=mysqli_fetch_array($e);
												echo "<h4>Requester Email Id: ",$email['Email']," </h4><br>";
											}
										}
									}	
								}			
								echo '</div>
								<div class="col-md-3"></div>
								<form method="post">
									<div class="col-md-3">
										<br>
										<select class="form-control" name="requester" id="requester">';
										$ress=mysqli_query($db,"select Requester_ID from buy_request where Product_ID='".$row['Product_ID']."'");
										if (mysqli_num_rows($ress)){	
											while ($row1=mysqli_fetch_array($ress)) {
												echo'<option>',$row1['Requester_ID'],'</option>';
											}
										}

										echo 	'
										</select>
									</div>	
									<div class="col-md-1">
										<br>
										<div class="text-center">
											<input class="btn btn-primary" type="submit" name="sold1" value="Sold" align="left" style="background-color:#001933;">
											<input class="btn btn-primary" type="hidden" name="sold" value="'.$row['Product_ID'].'" >
										</div>
									</div>	
								</form>
								</div>
								<hr>';
				
							}
						}
						if ($check==0){
							echo '<div class="row content">
									<div class="col-md-1"></div>
									<div class="col-md-6">
									<h3>No Advertisements posted Presently</h3>
									</div>	
								</div>';	
						}
					

						
						echo '<hr>';
						/*<div class="row content">';*/
					//}	
					//if (isset($interest)){
						if (mysqli_num_rows($interests)){

							while ($row11=mysqli_fetch_array($interests)) {
								$interest_product_id=$row11['Product_ID'];
								$interest_product=mysqli_fetch_array(mysqli_query($db,"select Seller_ID,Product_Name,Category,Decription,Expected_Price,Image1 from Product where Product_ID='$interest_product_id';"));
								$seller=mysqli_fetch_array(mysqli_query($db,"select * from user where User_ID='".$interest_product['Seller_ID']."';"));
								$seller_eid=mysqli_fetch_array(mysqli_query($db,"select Email from eid_profilepic where User_ID='".$interest_product['Seller_ID']."';"));
								
								echo '<div class="row content">
										<div class="col-md-4">	
											<div class="thumbnail">
												
												<tr>
													<td>
														<img src="data:image/jpeg;base64,'.base64_encode($interest_product['Image1']).'"/>
													</td>
												</tr>
											</div>
										</div>
										<div class="col-md-6">
											<div class="caption">

												<h3>',$interest_product['Product_Name'],'</h3>
												<p>Category : ',$interest_product['Category'],'</p>
												<p>Description : ',$interest_product['Decription'],'</p>
												<p>Price : &#x20B9 ' ,$interest_product['Expected_Price'],'/-</p>
												<h3>Seller Information : ',$seller['Username'],'</h3>
												<p>Seller ID : ',$interest_product['Seller_ID'],'</p>
												<p>Seller Email : ',$seller_eid['Email'],'</p>
												<p>Seller Contact no : ',$seller['Contact_no'],'</p>
					
											</div>
										</div>
										
									</div>
									<br><br><br>
									<hr>';
							}
						}
						else{
							echo '<div class="row content">
									<div class="col-md-1"></div>
									<div class="col-md-6">
									<h3>No Interests shown</h3>
									</div>	
								</div>';
						}
						echo '<hr>';
					//}	
					//if (isset($transaction)){
						echo '<div class="row content">
							<div class="col-md-12">	
								<table class="table table-bordered table-hover">
								    <thead  style="background-color:#001933;">
								      	<tr>
									        <th>Product</th>
									        <th>Product Id</th>
									        <th>Type</th>
									        <th>To/From</th>
									        <th>Status</th>
									        
									        <th>Price</th>
								      	</tr>
								    </thead>
								    <tbody>';
							      	
							      		$transactions_buy=mysqli_query($db,"select * from Product_invoice where Buyer_ID='$myusername';");
								        while($bought=mysqli_fetch_array($transactions_buy)){
								        	$product=mysqli_fetch_array(mysqli_query($db,"select Product_Name,Category,Seller_ID,Expected_Price from Product where Product_ID='".$bought['Product_ID']."';"));
									        echo'<tr>
									        <td>',$product['Product_Name'],'</td>
									        <td>',$bought['Product_ID'],'</td>
									        <td>Bought</td>
									        <td>',$bought['Seller_ID'],'</td>
									        <td>Completed</td>
									        <td>',$product['Expected_Price'],'</td></tr>';
								        }
								        
								        $transactions_sell=mysqli_query($db,"select * from Product_invoice where Seller_ID='$myusername';");
								        while($sold=mysqli_fetch_array($transactions_sell)){
									        $product1=mysqli_fetch_array(mysqli_query($db,"select Product_Name,Category,Seller_ID,Expected_Price from Product where Product_ID='".$sold['Product_ID']."';"));
									        echo'<tr>
									        <td>',$product1['Product_Name'],'</td>
									        <td>',$sold['Product_ID'],'</td>
									        <td>Sold</td>
									        <td>',$sold['Buyer_ID'],'</td>
									        <td>Completed</td>
									        <td>',$product1['Expected_Price'],'</td></tr>';
									    }    
						echo '		      	
								    </tbody>
								</table>
							</div>
						</div>';
					//}
				?>
				<hr>
			</div>
		</div>
	</div>
	<div class="container-fluid">
		<div class="row content" style=" background-color:#001933;">
			<div class="col-md-2"></div>
			<div class="col-md-6">
				<br><p>
				&copy; 2017, QwikSell</p><br>
			</div>
			<div class="col-md-4">
				<br>
				<img src="fb.png" alt="fb" style="width: 40px">
				<a href="#">QwikSell.com</a>|
				<a href="#">About Us</a>|
				<a href="#">Contact Us</a>
				<br>
			</div>
		</div>
	</div>

</body>
</html> 
